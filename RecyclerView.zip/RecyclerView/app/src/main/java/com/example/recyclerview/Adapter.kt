package com.example.recyclerview

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class ColorData(
    val colorName: String,
    val colorHex: String
)

class Adapter(private val context: Context,
              private val list: ArrayList<ColorData>,
              private val cellClickListener: CellClickListener
) : RecyclerView.Adapter<Adapter.ViewHolder>() {

    class ViewHolder(view: View): RecyclerView.ViewHolder(view) {
        val color: ImageView = view.findViewById(R.id.colorView)
        val text: TextView = view.findViewById(R.id.textView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(context).inflate(R.layout.rview_item, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = list[position]
        holder.color.setImageDrawable(ColorDrawable(Color.parseColor(data.colorHex)))
        holder.text.text = data.colorName
        holder.itemView.setOnClickListener {
            cellClickListener.onCellClickListener(data.colorName)
        }
    }

    override fun getItemCount() = list.size
}

interface CellClickListener {
    fun onCellClickListener(colorName: String)
}

