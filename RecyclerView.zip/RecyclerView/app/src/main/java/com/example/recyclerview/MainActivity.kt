package com.example.recyclerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import okhttp3.*
import java.io.IOException

class MainActivity : AppCompatActivity(), CellClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView: RecyclerView = findViewById(R.id.rView)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = Adapter(this, fetchList(), this)

        val btnOkHTTP = findViewById<Button>(R.id.btnOkHTTP)
        btnOkHTTP.setOnClickListener() {
            val client = OkHttpClient()
            val request = Request.Builder()
                .url("https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=ff49fcd4d4a08aa6aafb6ea3de826464&tags=cat&format=json&nojsoncallback=1")
                .build()

            client.newCall(request).enqueue(object: Callback {
                override fun onFailure(call: Call, e: IOException) {
                    e.printStackTrace()
                }
                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        if (!response.isSuccessful) throw IOException("Unexpected code $response")
                        Log.i("Flickr OkCats", response.body()!!.string())
                    }
                }
            })
        }
    }

    private fun fetchList() : ArrayList<ColorData> {
        val colorNames = this.resources.getStringArray(R.array.colorNames)
        val colorHexes = this.resources.getStringArray(R.array.colorHexes)
        val list = arrayListOf<ColorData>()
        for (color in colorNames.indices) {
            list.add(ColorData(colorNames[color], colorHexes[color]))
        }
        return list
    }

    override fun onCellClickListener(colorName: String) {
        Toast.makeText(this, "IT'S $colorName", Toast.LENGTH_SHORT).show()
    }
}